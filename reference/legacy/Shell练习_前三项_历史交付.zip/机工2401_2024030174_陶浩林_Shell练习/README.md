# Ubuntu 终端与 Shell 编程练习（练习 1—3）

- 班级：机工2401
- 学号：2024030174
- 姓名：陶浩林
- 范围：仅完成练习 1、练习 2、练习 3。

## 提交结构

```text
机工2401_2024030174_陶浩林_Shell练习/
├── scripts/
│   ├── path_practice.sh
│   ├── create_workspace.sh
│   ├── backup_config.sh
│   ├── temp_cleanup.sh
│   └── run_exercises_1_to_3.sh
├── output/
│   └── course.log                 # 在 Ubuntu 实测后自动生成
├── screenshots/
│   └── 截图说明.md
└── README.md
```

## Ubuntu 中的运行步骤

将整个提交文件夹复制到 Ubuntu 家目录后，打开终端并执行：

```bash
cd ~/机工2401_2024030174_陶浩林_Shell练习
chmod +x scripts/*.sh
./scripts/run_exercises_1_to_3.sh
```

也可以使用第二种脚本执行方式：

```bash
bash scripts/run_exercises_1_to_3.sh
```

`temp_cleanup.sh` 会执行题目指定的 `rm -i -- ./*.tmp`，仅删除 `~/ROS_Course/tmp_practice/` 中刚创建的 `.tmp` 文件；请对每个提示输入 `y`。脚本不含 `sudo`、`rm -rf`，也不会向 `/`、`/home`、`/etc`、`/usr`、`/var` 写入或删除内容。

## 练习对应关系

1. `path_practice.sh`：记录家目录、根目录、父目录、上次所在目录的 `pwd` 输出，并执行 `ls -alF`。`pwd` 输出均以 `/` 开头，故为绝对路径。
2. `create_workspace.sh`：在 `~/ROS_Course` 创建 `src/lesson2`、`src/lesson3`、`config`、`log`、`backup`，并创建 `robot.conf`、`lesson2.log`、`lesson3.log`。
3. `backup_config.sh`：依次使用 `cp -n`、`cp -u` 和 `mv -i`；`temp_cleanup.sh` 只在专用临时目录使用 `rm -i`。

## 符号说明（练习 1）

- `~`：当前用户的家目录。
- `/`：根目录。
- `.`：当前目录。
- `..`：父目录。
- `-`：上次所在目录（`cd -`）。

## 截图与运行记录

`output/course.log` 由综合运行脚本在 Ubuntu 中生成。请按 `screenshots/截图说明.md` 保存 3 张真实终端截图。它们没有在本机伪造或替代。
