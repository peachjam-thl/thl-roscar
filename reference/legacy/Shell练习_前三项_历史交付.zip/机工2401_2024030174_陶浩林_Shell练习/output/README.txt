运行 scripts/run_exercises_1_to_3.sh 后，会在此目录自动生成 course.log。
本目录不预置伪造的 Ubuntu 运行日志。
