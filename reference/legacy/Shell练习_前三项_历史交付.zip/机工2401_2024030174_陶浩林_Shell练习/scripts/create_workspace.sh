#!/usr/bin/env bash
# 练习 2：搭建 ROS 课程工作区
# 可重复执行；不会覆盖已经存在的 robot.conf。

set -u

WORKSPACE_NAME="ROS_Course"
WORKSPACE="$HOME/$WORKSPACE_NAME"
CONFIG_FILE="$WORKSPACE/config/robot.conf"

mkdir -p \
  "$WORKSPACE/src/lesson2" \
  "$WORKSPACE/src/lesson3" \
  "$WORKSPACE/config" \
  "$WORKSPACE/log" \
  "$WORKSPACE/backup"

if [ ! -e "$CONFIG_FILE" ]; then
  printf '%s\n' '# ROS course robot configuration' > "$CONFIG_FILE"
fi

touch "$WORKSPACE/log/lesson2.log" "$WORKSPACE/log/lesson3.log"

printf '练习 2：ROS 课程工作区已准备完成。\n'
printf '工作区绝对路径：\n'
cd "$WORKSPACE"
pwd

printf '\n[工作区列表：ls -alF]\n'
ls -alF
printf '\n[src 目录列表：ls -alF src]\n'
ls -alF src
printf '\n[config 目录列表：ls -alF config]\n'
ls -alF config
printf '\n[log 目录列表：ls -alF log]\n'
ls -alF log
printf '\n[backup 目录列表：ls -alF backup]\n'
ls -alF backup
