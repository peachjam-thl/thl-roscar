#!/usr/bin/env bash
# 练习 3：文件整理与安全备份
# 首次复制使用 cp -n；更新时使用 cp -u；重命名使用 mv -i。

set -u

WORKSPACE="$HOME/ROS_Course"
SOURCE="$WORKSPACE/config/robot.conf"
BACKUP_DIR="$WORKSPACE/backup"
BACKUP_FILE="$BACKUP_DIR/robot.conf"
RENAMED_FILE="$BACKUP_DIR/robot.conf.bak"

if [ ! -f "$SOURCE" ]; then
  printf '未找到 %s。请先运行 create_workspace.sh。\n' "$SOURCE" >&2
  exit 1
fi

mkdir -p "$BACKUP_DIR"

printf '首次复制：cp -n（不会覆盖已有备份）\n'
cp -nv "$SOURCE" "$BACKUP_FILE"

printf '更新备份：cp -u（仅当源文件较新或目标不存在时复制）\n'
cp -uv "$SOURCE" "$BACKUP_FILE"

if [ -e "$BACKUP_FILE" ]; then
  printf '安全改名：mv -i（若 robot.conf.bak 已存在会逐项询问）\n'
  mv -iv "$BACKUP_FILE" "$RENAMED_FILE"
fi

printf '\n[备份目录列表：ls -alF]\n'
ls -alF "$BACKUP_DIR"
