#!/usr/bin/env bash
# 练习 1：认识工作路径
# 仅改变当前脚本进程的工作目录，不修改或删除任何文件。

set -u

HOME_DIR="$HOME"

show_position() {
  printf '\n[%s]\n' "$1"
  pwd
  printf '判断：pwd 输出以 / 开头，因此是绝对路径。\n'
}

printf '练习 1：认识工作路径\n'

cd "$HOME_DIR"
show_position '家目录（起点）'

cd /
show_position '根目录：cd /'

# 在家目录的父目录中演示 cd ..，避免根目录的父目录仍为根目录而难以观察。
cd "$HOME_DIR"
cd ..
show_position '父目录：cd ..'

# 先进入根目录，再使用 cd - 返回刚才所在的目录，演示“上次所在目录”。
cd /
cd - >/dev/null
show_position '上次所在目录：cd -'

cd ~
show_position '返回家目录：cd ~'

printf '\n[家目录详细列表：ls -alF]\n'
ls -alF "$HOME_DIR"
