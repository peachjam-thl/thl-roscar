#!/usr/bin/env bash
# 练习 3：在专用临时练习目录中演示 rm -i *.tmp。
# 不使用递归强制删除，也不作用于系统目录。

set -u

TEMP_DIR="$HOME/ROS_Course/tmp_practice"
mkdir -p "$TEMP_DIR"
touch "$TEMP_DIR/draft.tmp" "$TEMP_DIR/cache.tmp" "$TEMP_DIR/notes.tmp"

printf '临时练习目录：%s\n' "$TEMP_DIR"
printf '删除前：\n'
ls -alF "$TEMP_DIR"

cd "$TEMP_DIR"
printf '\n执行 rm -i -- ./*.tmp；请逐项输入 y 确认删除。\n'
rm -i -- ./*.tmp

printf '\n删除后：\n'
ls -alF "$TEMP_DIR"
