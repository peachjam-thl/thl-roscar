#!/usr/bin/env bash
# 在 Ubuntu 中运行前三项练习并把非交互输出写入 ../output/course.log。

set -u

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SUBMISSION_DIR="$(cd -- "$SCRIPT_DIR/.." && pwd)"
OUTPUT_DIR="$SUBMISSION_DIR/output"
LOG_FILE="$OUTPUT_DIR/course.log"

mkdir -p "$OUTPUT_DIR"

{
  printf 'Ubuntu 终端与 Shell 编程练习（练习 1—3）\n'
  printf '运行时间：'
  date '+%F %T %Z'
  printf '\n===== 练习 1 =====\n'
  bash "$SCRIPT_DIR/path_practice.sh"
  printf '\n===== 练习 2 =====\n'
  bash "$SCRIPT_DIR/create_workspace.sh"
  printf '\n===== 练习 3：备份 =====\n'
  bash "$SCRIPT_DIR/backup_config.sh"
} 2>&1 | tee "$LOG_FILE"

printf '\n===== 练习 3：交互式 .tmp 清理 =====\n'
bash "$SCRIPT_DIR/temp_cleanup.sh" 2>&1 | tee -a "$LOG_FILE"

printf '\n运行记录已保存到：%s\n' "$LOG_FILE"
