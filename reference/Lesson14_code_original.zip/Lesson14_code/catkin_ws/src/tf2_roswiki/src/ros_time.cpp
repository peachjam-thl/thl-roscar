 #include <iostream>
 #include <ros/time.h>
 #include <ros/duration.h>


int main()
{
ros::Time::init();
//获取当前时间
ros::Time begin=ros::Time::now();
ros::Time double1=ros::Time();    
ros::Time double2=ros::Time(1);   

//实列
ros::Time at_some_time1(5,20000000);     //逗号之前表示 second，逗号之后表示 nanosecond
ros::Time at_some_time2(5.2);            //同上,重载了float类型和两个uint类型的构造函数
ros::Duration one_hour(60*60,0);         //1h
double secs1=at_some_time1.toSec();      //将 Time 转为 double 型时间
double secs2=one_hour.toSec();           //将 Duration 转为 double 型时间
std::cout << "Test1:" 
<< "\nbegin:" << begin
<< "\ndouble1:" << double1
<< "\ndouble2:" << double2   
<< "\nat_some_time1:" << at_some_time1 
<< "\nat_some_time2:" << at_some_time2 
<< "\none_hour:" << one_hour 
<< "\nsecs1:" << secs1 
<< "\nsecs2:" << secs2 
<< std::endl;

ros::Time t1=ros::Time::now()-ros::Duration(5.5);//t1是5.5s前的时刻,Time加减Duration返回Time
ros::Time t2=ros::Time::now()+ros::Duration(3.3);//t2是当前时刻往后推3.3s的时刻
ros::Duration d1=t2-t1;//从t1到t2的时长，两个Time相减返回Duration类型
ros::Duration d2=d1-ros::Duration(0,300);//两个Duration相减，返回Duration
std::cout << "\nTest2:" 
<< "\nt1:" << t1 
<< "\nt2:" << t2 
<< "\nd1:" << d1 
<< "\nd2:" << d2 
<< std::endl;

return 0;
}