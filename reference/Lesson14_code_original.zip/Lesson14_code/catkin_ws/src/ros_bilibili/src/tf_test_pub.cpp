/***************** tf发布文件 **********/
#include "ros/ros.h"
#include "turtlesim/Pose.h"
#include "tf2_ros/transform_broadcaster.h"
#include "geometry_msgs/TransformStamped.h"
#include "tf2/LinearMath/Quaternion.h"

int main(int argc, char *argv[])
{
    setlocale(LC_ALL,"");
    // 2.初始化 ROS 节点
    ros::init(argc,argv,"tf_test_pub");
    // 3.创建 ROS 句柄
    ros::NodeHandle nh;

    tf2_ros::TransformBroadcaster broadcaster;
    //  5-2.创建 广播的数据(通过 pose 设置)
    geometry_msgs::TransformStamped tfs;
    tfs.header.frame_id = "world";

    //  |----坐标系 ID
    tfs.child_frame_id = "turtle1";
    tfs.transform.rotation.w = 1.0;  

    ros::Rate rate(1);
    double x = 0.0;

    while(ros::ok())
    {
        //  |----坐标系相对信息设置
        tfs.transform.translation.x = x;
        ROS_INFO("Time Send: %d, x = %.2f", tfs.header.stamp.sec, x);
        
        tfs.header.stamp = ros::Time::now();  // 这样的时间才是正确的时间
        //  5-3.广播器发布数据
        broadcaster.sendTransform(tfs);
        x += 1.0;       
        rate.sleep();
        ros::spinOnce();
    }
    
    return 0;
}
