/*

需求:
    现有坐标系统，父级坐标系统 world,下有两个子级系统local1，local2，
    local1 相对于 world，以及 local2 相对于 world 的关系是已知的，
    (1) 求 local1 与 local2中的坐标关系;
    (2) 又已知在 local1中一点的坐标，求出该点在 local2 中的坐标
实现流程:
    1.包含头文件
    2.初始化 ros 节点
    3.创建 ros 句柄
    4.创建 TF 订阅对象
    5.1 解析订阅信息中获取 local1 坐标系原点在 local2 中的坐标
    5.2 解析 local1 中的点相对于 local2 的坐标
    6.spin

*/
//1.包含头文件
#include "ros/ros.h"
#include "tf2_ros/transform_listener.h"
#include "tf2/LinearMath/Quaternion.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.h"
#include "geometry_msgs/TransformStamped.h"
#include "geometry_msgs/PointStamped.h"

int main(int argc, char *argv[])
{   setlocale(LC_ALL,"");
    // 2.初始化 ros 节点
    ros::init(argc,argv,"tf_multi_sub");
    // 3.创建 ros 句柄
    ros::NodeHandle nh;
    // 4.创建 TF 订阅对象
    tf2_ros::Buffer buffer; 
    tf2_ros::TransformListener listener(buffer);
    // 5.解析订阅信息中获取 local1 坐标系原点在 local2 中的坐标
    ros::Rate rate(1);
    while (ros::ok())
    {
        try
        {
        //   解析 local1 中的点相对于 local2 的坐标
            geometry_msgs::TransformStamped tf;
            tf = buffer.lookupTransform("local2","local1",ros::Time(0));
            ROS_INFO("local1 相对于 local2 的坐标关系:父坐标系ID=%s",tf.header.frame_id.c_str());
            ROS_INFO("local1 相对于 local2 的坐标关系:子坐标系ID=%s",tf.child_frame_id.c_str());
            ROS_INFO("local1原点 在 local2 的坐标为:x=%.2f,y=%.2f,z=%.2f",
                    tf.transform.translation.x,
                    tf.transform.translation.y,
                    tf.transform.translation.z
                    );

            // 坐标点解析
            geometry_msgs::PointStamped ps_local1;
            ps_local1.header.frame_id = "local1";
            ps_local1.header.stamp = ros::Time::now();
            ps_local1.point.x = 2.0;
            ps_local1.point.y = 3.0;
            ps_local1.point.z = 5.0;

            geometry_msgs::PointStamped ps_local2;
            ps_local2 = buffer.transform(ps_local1,"local2");
            ROS_INFO("local1中的点 ps_local1 在 local2 中的坐标:x=%.2f,y=%.2f,z=%.2f",
                    ps_local2.point.x,
                    ps_local2.point.y,
                    ps_local2.point.z
                    );
        }
        catch(const std::exception& e)
        {
            // std::cerr << e.what() << '\n';
            ROS_INFO("tf_multi_sub 错误提示:%s",e.what());
        }

        rate.sleep();
        // 6.spin
        ros::spinOnce();
    }
    return 0;
}