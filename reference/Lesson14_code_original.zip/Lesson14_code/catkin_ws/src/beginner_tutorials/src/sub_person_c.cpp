#include "ros/ros.h"
#include "beginner_tutorials/person.h"

void doPerson(const beginner_tutorials::person::ConstPtr& person_p){
    ROS_INFO("发布人的信息:%s, %d, %.2f", person_p->name.c_str(), person_p->age, person_p->height);
}

int main(int argc, char *argv[])
{   
    setlocale(LC_ALL,"");
    ros::init(argc,argv,"listener_person");
    ros::NodeHandle nh;
    ros::Subscriber sub = nh.subscribe<beginner_tutorials::person>("chatter_person",10,doPerson);
    ros::spin();    
    return 0;
}
