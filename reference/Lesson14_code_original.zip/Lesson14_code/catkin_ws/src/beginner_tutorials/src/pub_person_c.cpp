#include "ros/ros.h"
#include "beginner_tutorials/person.h"

int main(int argc, char *argv[])
{
    setlocale(LC_ALL,"");
    ros::init(argc,argv,"talker_person");
    ros::NodeHandle nh;
    ros::Publisher pub = nh.advertise<beginner_tutorials::person>("chatter_person",1000);
    beginner_tutorials::person person;
    person.name = "ROSit";
    person.age = 0;
    person.height = 1.75;
    ros::Rate r(1);
    
while (ros::ok())
    {
        pub.publish(person);
        person.age += 1;
        ROS_INFO("我叫:%s,我今年%d岁,我的身高是%.2f米", person.name.c_str(), person.age, person.height);
        r.sleep();
        ros::spinOnce();
    }

    return 0;
}
